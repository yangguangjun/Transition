//
//  ViewController.h
//  YCustomTransition
//
//  Created by 杨广军 on 2020/12/31.
//

#import <UIKit/UIKit.h>
#import "YCustomCell.h"

@interface ViewController : UIViewController

@property (nonatomic, strong) YCustomCell *selectedCell;


@end

