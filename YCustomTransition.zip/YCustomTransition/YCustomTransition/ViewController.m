//
//  ViewController.m
//  YCustomTransition
//
//  Created by 杨广军 on 2020/12/31.
//

#import "ViewController.h"

#import "YPushTransition.h"
#import "YDetailController.h"

@interface ViewController ()<UICollectionViewDelegate, UICollectionViewDataSource, UINavigationControllerDelegate>

@property (nonatomic, strong) UICollectionView *collectionView;

@property (nonatomic, strong) NSArray *dataList;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    
    NSMutableArray *arr = [NSMutableArray arrayWithCapacity:6];
    for (int i = 1; i < 7; i++) {
        NSString *imageName = [NSString stringWithFormat:@"B%d",i];
        [arr addObject:imageName];
    }
    
    _dataList = [arr copy];
    
    
    UICollectionViewFlowLayout *layout = [[UICollectionViewFlowLayout alloc] init];
    layout.scrollDirection = UICollectionViewScrollDirectionVertical;
    layout.minimumLineSpacing = 20;
    layout.minimumInteritemSpacing = 20;
    layout.itemSize = CGSizeMake(150, 100);
    
    _collectionView = [[UICollectionView alloc] initWithFrame:self.view.bounds collectionViewLayout:layout];
    _collectionView.backgroundColor = [UIColor whiteColor];
    _collectionView.delegate = self;
    _collectionView.dataSource = self;
    [_collectionView registerClass:[YCustomCell class] forCellWithReuseIdentifier:@"yCell"];
    [self.view addSubview:_collectionView];
    
    
}

- (void) viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    // 设置代理必须放在每次进来都会运行的地方，不然pop回来代理就不会重新设置
    self.navigationController.delegate = self;
}

- (NSInteger) collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return _dataList.count;
}

- (__kindof UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    YCustomCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"yCell" forIndexPath:indexPath];
    
    NSString *imageName = [_dataList objectAtIndex:indexPath.row];
    UIImage *image = [UIImage imageNamed:imageName];
    cell.imageView.image = image;
    cell.label.text = [NSString stringWithFormat:@"item_%ld", (long)indexPath.row];
    
    return cell;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    YCustomCell *cell = (YCustomCell *)[collectionView cellForItemAtIndexPath:indexPath];
    _selectedCell = cell;
    
    YDetailController *vc = [[YDetailController alloc] init];
    [self.navigationController pushViewController:vc animated:YES];
}

- (nullable id <UIViewControllerAnimatedTransitioning>)navigationController:(UINavigationController *)navigationController
                                   animationControllerForOperation:(UINavigationControllerOperation)operation
                                                fromViewController:(UIViewController *)fromVC
                                                           toViewController:(UIViewController *)toVC {
    if (operation == UINavigationControllerOperationPush) {
        return [YPushTransition new];
    }else {
        return nil;
    }
}

@end
