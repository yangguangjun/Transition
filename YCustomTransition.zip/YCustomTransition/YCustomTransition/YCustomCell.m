//
//  YCustomCell.m
//  YCustomTransition
//
//  Created by 杨广军 on 2020/12/31.
//

#import "YCustomCell.h"

@interface YCustomCell()




@end

@implementation YCustomCell

- (instancetype) initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    
    if (self) {
      
        _imageView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, frame.size.width, frame.size.height - 30)];
        [self addSubview:_imageView];
        
        _label = [[UILabel alloc] initWithFrame:CGRectMake(0, frame.size.height - 25, frame.size.width, 25)];
        _label.textAlignment = NSTextAlignmentCenter;
        _label.textColor = [UIColor blackColor];
        _label.font = [UIFont systemFontOfSize:20 weight:UIFontWeightMedium];
        [self addSubview:_label];
    }
    
    return self;
}



@end
