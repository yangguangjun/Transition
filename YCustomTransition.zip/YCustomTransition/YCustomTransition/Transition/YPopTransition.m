//
//  yPopTransition.m
//  YCustomTransition
//
//  Created by 杨广军 on 2020/12/31.
//

#import "YPopTransition.h"
#import "ViewController.h"
#import "YDetailController.h"

@implementation YPopTransition


- (void)animateTransition:(nonnull id<UIViewControllerContextTransitioning>)transitionContext {
    
    YDetailController *fromVc = (YDetailController *)[transitionContext viewControllerForKey:UITransitionContextFromViewControllerKey];
    ViewController *toVc = (ViewController *)[transitionContext viewControllerForKey:UITransitionContextToViewControllerKey];
    UIView *container = [transitionContext containerView];
    
    UIView *tempView = [fromVc.detailImageView snapshotViewAfterScreenUpdates:NO];
    tempView.frame = [container convertRect:fromVc.detailImageView.frame fromView:fromVc.view];
    [fromVc.detailImageView setHidden:YES];
    
    [toVc.selectedCell.imageView setHidden:YES];
    
    [container insertSubview:toVc.view belowSubview:fromVc.view];
    [container addSubview:tempView];
    
    [UIView animateWithDuration:0.5 delay:0 options:UIViewAnimationOptionCurveEaseIn animations:^{
        fromVc.view.alpha = 0.0;
        tempView.frame = [container convertRect:toVc.selectedCell.imageView.frame fromView:toVc.selectedCell];
    } completion:^(BOOL finished) {
        [toVc.selectedCell.imageView setHidden:NO];
        [tempView removeFromSuperview];
        [fromVc.detailImageView setHidden:NO];
        
        [transitionContext completeTransition:![transitionContext transitionWasCancelled]];
    }];
    
}

- (NSTimeInterval)transitionDuration:(nullable id<UIViewControllerContextTransitioning>)transitionContext {
    return 0.5;
}


@end
