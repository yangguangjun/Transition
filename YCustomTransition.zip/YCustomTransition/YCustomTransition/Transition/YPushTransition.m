//
//  YPushTransition.m
//  YCustomTransition
//
//  Created by 杨广军 on 2020/12/31.
//

#import "YPushTransition.h"
#import "ViewController.h"
#import "YDetailController.h"


@interface YPushTransition()

@end

@implementation YPushTransition

- (void)animateTransition:(nonnull id<UIViewControllerContextTransitioning>)transitionContext {
    //1.获取动画的源控制器和目标控制器
    ViewController *fromVc = (ViewController *)[transitionContext viewControllerForKey:UITransitionContextFromViewControllerKey];
    YDetailController *toVc = (YDetailController *)[transitionContext viewControllerForKey:UITransitionContextToViewControllerKey];
    UIView *container = [transitionContext containerView];
    //2.创建一个 Cell 中 imageView 的截图，并把 imageView 隐藏，造成使用户以为移动的就是 imageView 的假象
    UIView *tempView = [fromVc.selectedCell.imageView snapshotViewAfterScreenUpdates:NO];
    tempView.frame = [container convertRect:fromVc.selectedCell.imageView.frame fromView:fromVc.selectedCell];
    [fromVc.selectedCell.imageView setHidden:YES];
    //3.设置目标控制器的位置，并把透明度设为0，在后面的动画中慢慢显示出来变为1
    toVc.view.alpha = 0.0;
    //4.都添加到 container 中。注意顺序不能错了
    [container addSubview:toVc.view];
    [container addSubview:tempView];
    //5.执行动画
    [UIView animateWithDuration:0.5 delay:0 options:UIViewAnimationOptionCurveEaseIn animations:^{
        toVc.view.alpha = 1.0;
        tempView.frame = toVc.detailImageView.frame;
    } completion:^(BOOL finished) {
        [fromVc.selectedCell.imageView setHidden:NO];
        toVc.detailImageView.image = fromVc.selectedCell.imageView.image;
        [tempView removeFromSuperview];
        //一定要记得动画完成后执行此方法，让系统管理 navigation
        [transitionContext completeTransition:YES];
    }];
    
}

- (NSTimeInterval)transitionDuration:(nullable id<UIViewControllerContextTransitioning>)transitionContext {
    return 0.5;
}

@end
